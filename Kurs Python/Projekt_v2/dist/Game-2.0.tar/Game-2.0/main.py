from Game import demo


if __name__ == '__main__':
    demo.start()


