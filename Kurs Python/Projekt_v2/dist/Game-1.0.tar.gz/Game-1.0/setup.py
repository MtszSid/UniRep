from distutils.core import setup

setup(name='Game',
      version='1.0',
      author='Greg Ward',
      author_email='gward@python.net',
      packages=['Game'],
      )
